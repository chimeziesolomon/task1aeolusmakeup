<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Classroom_items extends Model
{
    //
}
